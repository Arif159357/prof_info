const express = require('express');
const router = new express.Router();
const mongoose = require('mongoose');
const Professor = mongoose.model('Professor');
